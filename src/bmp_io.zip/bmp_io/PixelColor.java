package bmp_io;

public class PixelColor {
	int r;
	int b;
	int g;
	
	public PixelColor(int r, int g, int b) {
		this.r = r;
		this.b = b;
		this.g = g;
	}
}
